import type { FastifyInstance } from 'fastify';
import { authMiddleware } from '../auth/auth-middleware.js';
import { zaloPool } from './zalo-pool.js';
import { prisma } from '../../shared/database/prisma-client.js';
import { requireRole } from '../auth/role-middleware.js';

/**
 * Zalo account management routes.
 */
async function zaloRoutes(app: FastifyInstance): Promise<void> {
  // All routes in this plugin require auth
  app.addHook('preHandler', authMiddleware);

  // GET /api/v1/zalo-accounts — list accounts with live status from pool
  app.get('/api/v1/zalo-accounts', async (request) => {
    const user = request.user!;
    const where: any = { orgId: user.orgId };

    // Role-based visibility
    if (user.role === 'member') {
      where.OR = [
        { access: { some: { userId: user.id } } },
        { 
          conversations: { 
            some: { 
              OR: [
                // Assigned to them
                { contact: { assignedUserId: user.id } },
                { members: { some: { contact: { assignedUserId: user.id } } } },
                // OR Unassigned/New (for support)
                { threadType: 'user', contact: { assignedUserId: null } },
                { threadType: 'group', members: { none: { contact: { assignedUserId: { not: null } } } } }
              ]
            } 
          } 
        }
      ];
    } else if (user.role === 'leader') {
      where.OR = [
        { owner: { team: { leaderId: user.id } } },
        { access: { some: { user: { team: { leaderId: user.id } } } } }
      ];
    }

    const accounts = await prisma.zaloAccount.findMany({
      where,
      select: {
        id: true,
        zaloUid: true,
        displayName: true,
        avatarUrl: true,
        phone: true,
        status: true,
        lastConnectedAt: true,
        createdAt: true,
        owner: { select: { id: true, fullName: true, email: true } },
      },
      orderBy: { createdAt: 'asc' },
    });

    return accounts.map((a) => ({
      ...a,
      liveStatus: zaloPool.getStatus(a.id),
    }));
  });

  // POST /api/v1/zalo-accounts — create a new account record
  app.post<{ Body: { displayName?: string } }>(
    '/api/v1/zalo-accounts',
    { preHandler: requireRole('owner', 'admin') },
    async (request, reply) => {
      const user = request.user!;
      const { displayName } = (request.body as any) ?? {};

      const account = await prisma.zaloAccount.create({
        data: {
          orgId: user.orgId,
          ownerUserId: user.id,
          displayName: displayName ?? null,
          status: 'qr_pending',
        },
      });

      return reply.status(201).send(account);
    },
  );

  // POST /api/v1/zalo-accounts/:id/login
  app.post('/api/v1/zalo-accounts/:id/login', { preHandler: requireRole('owner', 'admin') }, async (request, reply) => {
    const { id } = request.params as { id: string };
    const user = request.user!;

    const account = await prisma.zaloAccount.findFirst({
      where: { id, orgId: user.orgId },
    });
    if (!account) return reply.status(404).send({ error: 'Account not found' });

    zaloPool.loginQR(id).catch(() => {});
    return { message: 'QR login initiated' };
  });

  // POST /api/v1/zalo-accounts/:id/reconnect
  app.post('/api/v1/zalo-accounts/:id/reconnect', { preHandler: requireRole('owner', 'admin') }, async (request, reply) => {
    const { id } = request.params as { id: string };
    const user = request.user!;

    const account = await prisma.zaloAccount.findFirst({
      where: { id, orgId: user.orgId },
    });
    if (!account) return reply.status(404).send({ error: 'Account not found' });

    const session = account.sessionData as any;
    if (!session?.imei) return reply.status(400).send({ error: 'No saved session' });

    zaloPool.reconnect(id, session).catch(() => {});
    return { message: 'Reconnect initiated' };
  });

  // DELETE /api/v1/zalo-accounts/:id
  app.delete('/api/v1/zalo-accounts/:id', { preHandler: requireRole('owner', 'admin') }, async (request, reply) => {
    const { id } = request.params as { id: string };
    const user = request.user!;

    const account = await prisma.zaloAccount.findFirst({
      where: { id, orgId: user.orgId },
    });
    if (!account) return reply.status(404).send({ error: 'Account not found' });

    zaloPool.disconnect(id);
    await prisma.zaloAccount.delete({ where: { id } });
    return reply.status(204).send();
  });

  // GET /api/v1/zalo-accounts/:id/status
  app.get('/api/v1/zalo-accounts/:id/status', async (request, reply) => {
    const { id } = request.params as { id: string };
    const user = request.user!;

    const where: any = { id, orgId: user.orgId };
    if (user.role === 'member') {
      where.access = { some: { userId: user.id } };
    } else if (user.role === 'leader') {
      where.OR = [
        { owner: { team: { leaderId: user.id } } },
        { access: { some: { user: { team: { leaderId: user.id } } } } }
      ];
    }

    const account = await prisma.zaloAccount.findFirst({
      where,
      select: { id: true, status: true },
    });
    if (!account) return reply.status(403).send({ error: 'Access denied' });

    return { accountId: id, liveStatus: zaloPool.getStatus(id) };
  });
}

export { zaloRoutes };
