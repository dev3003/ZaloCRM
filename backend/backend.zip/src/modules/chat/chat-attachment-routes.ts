import { FastifyInstance } from 'fastify';
import { prisma } from '../../database/prisma';
import { StorageService } from '../storage/storage-service';
import { MessageDispatcher } from './message-dispatcher';

export async function chatAttachmentRoutes(app: FastifyInstance) {
  app.post('/conversations/:id/attachments', async (req, reply) => {
    const { id: conversationId } = req.params as { id: string };
    const parts = req.parts();
    
    let fileBuffer: Buffer | null = null;
    let fileName = '';
    let fileType = '';
    let caption = '';

    for await (const part of parts) {
      if (part.file) {
        fileBuffer = await part.toBuffer();
        fileName = part.filename;
        fileType = part.mimetype;
      } else {
        // Handle fields like 'caption'
        if (part.fieldname === 'caption') {
          caption = (part as any).value;
        }
      }
    }

    if (!fileBuffer) {
      return reply.status(400).send({ error: 'No file uploaded' });
    }

    const conversation = await prisma.conversation.findUnique({
      where: { id: conversationId },
      include: { zaloAccount: true, contact: true }
    });

    if (!conversation) {
      return reply.status(404).send({ error: 'Conversation not found' });
    }

    try {
      // 1. Process and store file (Classification + Video Processing)
      const storageResult = await StorageService.processMessageFiles([{
        buffer: fileBuffer,
        originalname: fileName,
        mimetype: fileType
      }]);

      const attachment = storageResult[0];

      // 2. Dispatch to Zalo
      await MessageDispatcher.dispatch({
        conversationId: conversation.id,
        zaloAccountId: conversation.zaloAccountId,
        externalConversationId: conversation.contact?.zaloUid || '',
        threadType: conversation.threadType as any,
        contentType: attachment.type as any,
        content: attachment.url, // Original URL
        payload: {
          name: fileName,
          size: fileBuffer.length,
          type: attachment.type,
          url: attachment.url,
          thumb: attachment.thumb,
          duration: attachment.duration,
          width: attachment.width,
          height: attachment.height,
          caption: caption
        }
      });

      return { success: true, attachment };
    } catch (error: any) {
      req.log.error(error);
      return reply.status(500).send({ error: error.message });
    }
  });
}
