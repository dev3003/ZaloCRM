import { randomUUID } from 'node:crypto';
import { prisma } from '../../shared/database/prisma-client.js';
import { zaloPool } from '../zalo/zalo-pool.js';
import { logger } from '../../shared/utils/logger.js';

export interface DispatchMessage {
  conversationId: string;
  zaloAccountId: string;
  externalConversationId: string;
  threadType: 0 | 1; // 0=User, 1=Group
  contentType: 'text' | 'image' | 'video' | 'file';
  content: string;
  payload?: any;
}

export class MessageDispatcher {
  static async dispatch(msg: DispatchMessage) {
    const instance = zaloPool.getInstance(msg.zaloAccountId);
    if (!instance?.api) throw new Error('Zalo account not connected');

    try {
      let zaloMsgId: string | undefined;

      if (msg.contentType === 'video') {
        // Use native video API if possible (gca-js / zca-js sendVideo)
        // Check if sendVideo exists in this version of the API
        if (typeof (instance.api as any).sendVideo === 'function') {
          const videoPayload = {
            url: msg.payload.url,
            thumb: msg.payload.thumb,
            duration: msg.payload.duration || 0,
            width: msg.payload.width || 480,
            height: msg.payload.height || 320,
            name: msg.payload.name || 'video.mp4',
            caption: msg.payload.caption || ''
          };
          logger.info(`[dispatcher] Sending native video to ${msg.externalConversationId}`);
          await (instance.api as any).sendVideo(videoPayload, msg.externalConversationId, msg.threadType);
        } else {
          // Fallback to sendMessage with JSON if native not available (unlikely)
          await instance.api.sendMessage({ msg: msg.content }, msg.externalConversationId, msg.threadType);
        }
      } else if (msg.contentType === 'image') {
        // For images, we can use sendMessage or specific image API
        await instance.api.sendMessage({ msg: msg.content }, msg.externalConversationId, msg.threadType);
      } else {
        // Default text/file
        await instance.api.sendMessage({ msg: msg.content }, msg.externalConversationId, msg.threadType);
      }

      // Persist to DB
      const message = await prisma.message.create({
        data: {
          id: randomUUID(),
          conversationId: msg.conversationId,
          senderType: 'self',
          senderUid: '', // Will be filled by listener or pool
          senderName: 'Staff',
          content: msg.contentType === 'text' ? msg.content : JSON.stringify(msg.payload || { url: msg.content }),
          contentType: msg.contentType,
          sentAt: new Date(),
          fileStatus: msg.contentType === 'text' ? 'none' : 'success',
        },
      });

      await prisma.conversation.update({
        where: { id: msg.conversationId },
        data: { lastMessageAt: new Date(), isReplied: true, unreadCount: 0 },
      });

      return message;
    } catch (error) {
      logger.error('[dispatcher] Dispatch error:', error);
      throw error;
    }
  }
}
